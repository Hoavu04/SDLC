<?php 
    function alert_message($message) {
        echo '<script type="text/javascript">console.log("' . $message . '")</script>';
    }
?>